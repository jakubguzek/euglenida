# Autotroficzne eugleniny w małych zbiornikach wodnych.

Zestaw skrytów do analizy danych na projekt zaliczeniowy z metagenomiki.
