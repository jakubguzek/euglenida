import argparse
import pathlib
from typing import List, Optional, Union

from euglenida import utils


def qiime_classify(
    qiime_path: str,
    classifier_path: Union[pathlib.Path, str],
    reads_path: Union[pathlib.Path, str],
    output_path: Union[pathlib.Path, str],
) -> List[str]:
    return [
        qiime_path,
        "feature-classifier",
        "classify-sklearn",
        "--i-classifier",
        f"{classifier_path}",
        "--i-reads",
        f"{reads_path}",
        "--o-classification",
        f"{output_path}",
    ]


def qiime_metadata_tabulate(
    qiime_path: str,
    classification_path: Union[pathlib.Path, str],
    classification_visualization_path: Union[pathlib.Path, str],
) -> List[str]:
    return [
        qiime_path,
        "metadata",
        "tabulate",
        "--m-input-file",
        f"{classification_path}",
        "--o-visualization",
        f"{classification_visualization_path}",
    ]


def qiime_taxa_barplot(
    qiime_path: str,
    table_path: Union[pathlib.Path, str],
    classification_path: Union[pathlib.Path, str],
    output_barplot_path: Union[pathlib.Path, str],
    metadata_file: Optional[Union[pathlib.Path, str]] = None
) -> List[str]:
    if metadata_file is not None:
        return [
            qiime_path,
            "taxa",
            "barplot",
            "--0-table",
            f"{table_path}",
            "--i-taxonomy",
            f"{classification_path}",
            "--m-metadata-file",
            f"{metadata_file}",
            "--o-visualization",
            f"{output_barplot_path}",
        ]
    return [
        qiime_path,
        "taxa",
        "barplot",
        "--0-table",
        f"{table_path}",
        "--i-taxonomy",
        f"{classification_path}",
        "--o-visualization",
        f"{output_barplot_path}",
    ]


def classify(args: argparse.Namespace, script_name: str) -> int:
    if args.verbose:
        utils.print_args(args, script_name=script_name)

    if args.qiime_path is None:
        print(
            f"\033[31m\033[1m{script_name}: error:\033[0m: could not find qiime2 executable in $PATH"  # ]]]
        )
        return 1

    classifier = pathlib.Path(args.classifier)
    if not classifier.exists():
        print(
            f"\033[31m\033[1m{script_name}: error:\033[0m: {classifier}: No such file or directory!"  # ]]]
        )
        return 1

    reads_path = pathlib.Path(args.input_sequences)
    if not reads_path.exists():
        print(
            f"\033[31m\033[1m{script_name}: error:\033[0m: {reads_path}: No such file or directory!"  # ]]]
        )
        return 1

    table_path = pathlib.Path(args.input_table)
    if not table_path.exists():
        print(
            f"\033[31m\033[1m{script_name}: error:\033[0m: {table_path}: No such file or directory!"  # ]]]
        )
        return 1

    # Validate outdir path. If it doesn't exist, create it.
    output_dir: pathlib.Path = pathlib.Path(args.outdir)
    if not output_dir.exists():
        output_dir.mkdir()

    # Handle the changing of qiime2 tmp directory. If not done can sometimes lead
    # to errors during runnign qiime2 commands
    tmp_dir = pathlib.Path(args.tmp_dir)
    if not tmp_dir.exists():
        tmp_dir.mkdir()
    utils.change_tmp_dir(tmp_dir)

    classification_path = output_dir / "classification.qza"
    classification_command = qiime_classify(
        args.qiime_path, classifier, reads_path, classification_path
    )
    utils.run_command_with_output(classification_command, args, script_name)

    classification_metadata_path = classification_path.with_suffix(".qzv")
    metadata_tabulate_command = qiime_metadata_tabulate(
        args.qiime, classification_path, classification_metadata_path
    )
    utils.run_command_with_output(metadata_tabulate_command, args, script_name)

    barplot_output_path = output_dir / "barplot.qzv"

    if args.metadata is not None:
        metadata = pathlib.Path(args.metadata)
        if not metadata.exists() and args.verbose:
            print(
                f"\033[31m\033[1m{script_name}: error:\033[0m: {table_path}: No such file or directory!"  # ]]]
            )
        taxa_barplot_command = qiime_taxa_barplot(
            args.qiime_path, table_path, classification_path, barplot_output_path, metadata
        )
    else:
        taxa_barplot_command = qiime_taxa_barplot(
            args.qiime_path, table_path, classification_path, barplot_output_path
        )

    utils.run_command_with_output(taxa_barplot_command, args, script_name)

    return 0
