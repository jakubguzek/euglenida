#!/usr/bin/env bash
mkdir -vp "./results/fastqc"

mkdir -vp "./results/multiqc"
